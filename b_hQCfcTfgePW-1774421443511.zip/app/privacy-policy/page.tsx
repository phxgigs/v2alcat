import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Privacy Policy | Alcatraz Lock & Key",
  description: "Privacy Policy for Alcatraz Lock & Key. Learn how we collect, use, and protect your personal information.",
}

export default function PrivacyPolicyPage() {
  return (
    <div className="bg-zinc-950 py-20">
      <div className="max-w-4xl mx-auto px-4">
        <h1 className="text-4xl font-bold text-white mb-8">Privacy Policy</h1>
        <p className="text-zinc-400 mb-6">Last Updated: January 2024</p>
        
        <div className="prose prose-invert prose-zinc max-w-none space-y-8">
          <section>
            <h2 className="text-2xl font-semibold text-white mb-4">Introduction</h2>
            <p className="text-zinc-400">
              Alcatraz Lock & Key (&quot;we,&quot; &quot;our,&quot; or &quot;us&quot;) is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website alcatrazlock.com or use our locksmith services.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mb-4">Information We Collect</h2>
            <p className="text-zinc-400 mb-4">We may collect information about you in a variety of ways, including:</p>
            <ul className="list-disc list-inside text-zinc-400 space-y-2">
              <li><strong className="text-white">Personal Data:</strong> Name, phone number, email address, and service address when you contact us or request services.</li>
              <li><strong className="text-white">Service Information:</strong> Details about the locksmith services you request, including vehicle information, property details, and service history.</li>
              <li><strong className="text-white">Usage Data:</strong> Information about how you interact with our website, including IP address, browser type, and pages visited.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mb-4">How We Use Your Information</h2>
            <p className="text-zinc-400 mb-4">We use the information we collect to:</p>
            <ul className="list-disc list-inside text-zinc-400 space-y-2">
              <li>Provide, operate, and maintain our locksmith services</li>
              <li>Respond to your inquiries and service requests</li>
              <li>Send you service confirmations and updates</li>
              <li>Improve our website and services</li>
              <li>Comply with legal obligations</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mb-4">Information Sharing</h2>
            <p className="text-zinc-400">
              We do not sell, trade, or rent your personal information to third parties. We may share your information with trusted service providers who assist us in operating our business, provided they agree to keep your information confidential.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mb-4">Data Security</h2>
            <p className="text-zinc-400">
              We implement appropriate technical and organizational measures to protect your personal information against unauthorized access, alteration, disclosure, or destruction. However, no method of transmission over the Internet is 100% secure.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mb-4">Your Rights</h2>
            <p className="text-zinc-400 mb-4">You have the right to:</p>
            <ul className="list-disc list-inside text-zinc-400 space-y-2">
              <li>Access the personal information we hold about you</li>
              <li>Request correction of inaccurate information</li>
              <li>Request deletion of your personal information</li>
              <li>Opt-out of marketing communications</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mb-4">Cookies</h2>
            <p className="text-zinc-400">
              Our website may use cookies and similar tracking technologies to enhance your browsing experience. You can set your browser to refuse cookies, but some features of our website may not function properly.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mb-4">Contact Us</h2>
            <p className="text-zinc-400">
              If you have questions about this Privacy Policy, please contact us at:
            </p>
            <div className="mt-4 text-zinc-400">
              <p><strong className="text-white">Alcatraz Lock & Key</strong></p>
              <p>Phone: <a href="tel:6026775045" className="text-amber-500 hover:text-amber-400">(602) 677-5045</a></p>
              <p>Email: <a href="mailto:service@alcatrazlock.com" className="text-amber-500 hover:text-amber-400">service@alcatrazlock.com</a></p>
            </div>
          </section>
        </div>
      </div>
    </div>
  )
}

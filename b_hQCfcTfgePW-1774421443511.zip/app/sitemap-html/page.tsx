import { Metadata } from "next"
import Link from "next/link"

export const metadata: Metadata = {
  title: "Sitemap | Alcatraz Lock & Key | Phoenix Locksmith",
  description: "Complete sitemap of Alcatraz Lock & Key website. Find all our locksmith services, locations, and pages.",
  robots: { index: true, follow: true },
}

const mainPages = [
  { title: "Home", href: "/", description: "24/7 Emergency Locksmith Service in Phoenix" },
  { title: "Contact", href: "/contact", description: "Get a free quote or schedule service" },
  { title: "Service Areas", href: "/service-areas", description: "Cities we serve in the Phoenix Metro Area" },
  { title: "Privacy Policy", href: "/privacy-policy", description: "Our privacy policy" },
  { title: "Terms of Service", href: "/terms-of-service", description: "Terms and conditions" },
]

const servicePages = [
  { title: "Automotive Locksmith", href: "/automotive", description: "Car lockouts, key replacement, ignition repair" },
  { title: "Residential Locksmith", href: "/residential", description: "House lockouts, lock rekeying, smart locks" },
  { title: "Commercial Locksmith", href: "/commercial", description: "Business security, access control, master keys" },
  { title: "Safe Services", href: "/safe-services", description: "Safe cracking, repair, installation, gun safes" },
]

const locationPages = [
  { title: "Phoenix Locksmith", href: "/locations/phoenix" },
  { title: "Scottsdale Locksmith", href: "/locations/scottsdale" },
  { title: "Tempe Locksmith", href: "/locations/tempe" },
  { title: "Glendale Locksmith", href: "/locations/glendale" },
  { title: "Peoria Locksmith", href: "/locations/peoria" },
  { title: "Paradise Valley Locksmith", href: "/locations/paradise-valley" },
  { title: "Sun City Locksmith", href: "/locations/sun-city" },
  { title: "Anthem Locksmith", href: "/locations/anthem" },
]

export default function SitemapHtmlPage() {
  return (
    <div className="bg-zinc-950 min-h-screen py-16">
      <div className="max-w-4xl mx-auto px-4">
        <h1 className="text-4xl font-bold text-white mb-8">Sitemap</h1>
        <p className="text-zinc-400 mb-12">
          Navigate all pages of Alcatraz Lock & Key - your trusted Phoenix locksmith.
        </p>

        {/* Main Pages */}
        <section className="mb-12">
          <h2 className="text-2xl font-semibold text-white mb-4">Main Pages</h2>
          <ul className="space-y-3">
            {mainPages.map((page) => (
              <li key={page.href}>
                <Link href={page.href} className="text-amber-500 hover:text-amber-400 font-medium">
                  {page.title}
                </Link>
                <span className="text-zinc-500 ml-2">- {page.description}</span>
              </li>
            ))}
          </ul>
        </section>

        {/* Service Pages */}
        <section className="mb-12">
          <h2 className="text-2xl font-semibold text-white mb-4">Services</h2>
          <ul className="space-y-3">
            {servicePages.map((page) => (
              <li key={page.href}>
                <Link href={page.href} className="text-amber-500 hover:text-amber-400 font-medium">
                  {page.title}
                </Link>
                <span className="text-zinc-500 ml-2">- {page.description}</span>
              </li>
            ))}
          </ul>
        </section>

        {/* Location Pages */}
        <section className="mb-12">
          <h2 className="text-2xl font-semibold text-white mb-4">Service Locations</h2>
          <ul className="grid grid-cols-2 gap-3">
            {locationPages.map((page) => (
              <li key={page.href}>
                <Link href={page.href} className="text-amber-500 hover:text-amber-400 font-medium">
                  {page.title}
                </Link>
              </li>
            ))}
          </ul>
        </section>

        {/* Technical */}
        <section>
          <h2 className="text-2xl font-semibold text-white mb-4">Technical</h2>
          <ul className="space-y-3">
            <li>
              <a href="/sitemap.xml" className="text-amber-500 hover:text-amber-400 font-medium">
                XML Sitemap
              </a>
              <span className="text-zinc-500 ml-2">- For search engines</span>
            </li>
            <li>
              <a href="/robots.txt" className="text-amber-500 hover:text-amber-400 font-medium">
                Robots.txt
              </a>
              <span className="text-zinc-500 ml-2">- Crawler instructions</span>
            </li>
          </ul>
        </section>
      </div>
    </div>
  )
}

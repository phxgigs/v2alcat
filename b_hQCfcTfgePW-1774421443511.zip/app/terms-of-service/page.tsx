import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Terms of Service | Alcatraz Lock & Key",
  description: "Terms of Service for Alcatraz Lock & Key locksmith services in Phoenix, Arizona.",
}

export default function TermsOfServicePage() {
  return (
    <div className="bg-zinc-950 py-20">
      <div className="max-w-4xl mx-auto px-4">
        <h1 className="text-4xl font-bold text-white mb-8">Terms of Service</h1>
        <p className="text-zinc-400 mb-6">Last Updated: January 2024</p>
        
        <div className="prose prose-invert prose-zinc max-w-none space-y-8">
          <section>
            <h2 className="text-2xl font-semibold text-white mb-4">Agreement to Terms</h2>
            <p className="text-zinc-400">
              By accessing or using the services of Alcatraz Lock & Key (&quot;Company,&quot; &quot;we,&quot; &quot;our,&quot; or &quot;us&quot;), you agree to be bound by these Terms of Service. If you do not agree to these terms, please do not use our services.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mb-4">Services</h2>
            <p className="text-zinc-400 mb-4">Alcatraz Lock & Key provides professional locksmith services including but not limited to:</p>
            <ul className="list-disc list-inside text-zinc-400 space-y-2">
              <li>Automotive locksmith services (car lockouts, key replacement, fob programming)</li>
              <li>Residential locksmith services (house lockouts, lock rekeying, deadbolt installation)</li>
              <li>Commercial locksmith services (access control, master key systems, panic bars)</li>
              <li>Safe services (safe cracking, repairs, combination changes)</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mb-4">Service Area</h2>
            <p className="text-zinc-400">
              We provide mobile locksmith services throughout the Phoenix Metropolitan Area, including Phoenix, Scottsdale, Tempe, Mesa, Glendale, Peoria, Paradise Valley, Chandler, Gilbert, Anthem, Sun City, and surrounding communities.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mb-4">Pricing and Payment</h2>
            <ul className="list-disc list-inside text-zinc-400 space-y-2">
              <li>Prices are provided as estimates and may vary based on the complexity of the job</li>
              <li>Final pricing will be confirmed before work begins</li>
              <li>Payment is due upon completion of services</li>
              <li>We accept cash, credit cards, and debit cards</li>
              <li>Service call fees may apply and will be disclosed upfront</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mb-4">Proof of Ownership</h2>
            <p className="text-zinc-400">
              For security purposes, we may require proof of ownership or authorization before providing locksmith services. This may include valid identification, vehicle registration, lease agreements, or other documentation. We reserve the right to refuse service if adequate proof cannot be provided.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mb-4">Warranty</h2>
            <p className="text-zinc-400">
              We stand behind our work. Parts and labor are warranted for 90 days from the date of service, unless otherwise specified. This warranty does not cover damage caused by misuse, attempted repairs by others, or normal wear and tear.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mb-4">Limitation of Liability</h2>
            <p className="text-zinc-400">
              Alcatraz Lock & Key shall not be liable for any indirect, incidental, special, consequential, or punitive damages arising from the use of our services. Our total liability shall not exceed the amount paid for the specific service in question.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mb-4">Licensing and Insurance</h2>
            <p className="text-zinc-400">
              Alcatraz Lock & Key is a licensed, bonded, and insured locksmith company operating in the State of Arizona. We carry liability insurance to protect our customers and their property.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mb-4">Cancellation Policy</h2>
            <p className="text-zinc-400">
              If you need to cancel a scheduled appointment, please notify us at least 2 hours in advance. Cancellations made after the technician has been dispatched may be subject to a service call fee.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mb-4">Governing Law</h2>
            <p className="text-zinc-400">
              These Terms of Service shall be governed by and construed in accordance with the laws of the State of Arizona, without regard to its conflict of law provisions.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mb-4">Changes to Terms</h2>
            <p className="text-zinc-400">
              We reserve the right to modify these Terms of Service at any time. Changes will be effective immediately upon posting to our website. Your continued use of our services constitutes acceptance of any modified terms.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mb-4">Contact Us</h2>
            <p className="text-zinc-400">
              If you have questions about these Terms of Service, please contact us at:
            </p>
            <div className="mt-4 text-zinc-400">
              <p><strong className="text-white">Alcatraz Lock & Key</strong></p>
              <p>Phone: <a href="tel:6026775045" className="text-amber-500 hover:text-amber-400">(602) 677-5045</a></p>
              <p>Email: <a href="mailto:service@alcatrazlock.com" className="text-amber-500 hover:text-amber-400">service@alcatrazlock.com</a></p>
            </div>
          </section>
        </div>
      </div>
    </div>
  )
}

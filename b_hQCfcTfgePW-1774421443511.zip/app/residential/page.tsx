import { Metadata } from "next"
import Link from "next/link"
import Script from "next/script"
import { Home, Key, Lock, Smartphone, CheckCircle } from "lucide-react"
import { QuoteSidebar } from "@/components/quote-sidebar"
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"

export const metadata: Metadata = {
  title: "Residential Locksmith Phoenix | Home Rekey & Smart Lock Installation",
  description: "Professional residential locksmith services in Phoenix. Lock rekeying, smart lock installation, house lockouts, deadbolt installation, door lock repair. Best locksmith near me. Licensed & insured.",
  keywords: ["residential locksmith near me", "door locksmith near me", "door lock repair near me", "lock repair near me", "best locksmith near me", "key cutting services near me", "key replacement services near me", "get keys cut near me", "keys made nearby"],
}

const services = [
  {
    title: "Lock Rekeying & Replacement",
    description: "Did you know you don't have to replace your entire lock hardware to change your keys? Rekeying is a cost-effective way to secure your home by changing the internal pins so old keys no longer work.",
    features: [
      "New Homeowner Rekeying",
      "Master Key Systems",
      "High-Security Cylinder Upgrades",
      "Broken Key Extraction",
      "Mailbox Lock Replacement",
      "Gate & Padlock Rekeying",
    ],
  },
  {
    title: "Smart Locks & Security Upgrades",
    description: "Upgrade your home with keyless entry convenience. We install and program top-rated smart locks that allow you to control access from your phone, perfect for families, dog walkers, or rental properties.",
    features: [
      "Keyless Entry Deadbolts",
      "Wi-Fi & Bluetooth Smart Locks",
      "Video Doorbell Integration",
      "Door Jamb Reinforcement",
      "Peephole Installation",
      "Sliding Door Security Bars",
    ],
  },
  {
    title: "Emergency House Lockouts",
    description: "Locked out of your house? We provide fast, non-destructive entry. We can pick almost any residential lock, getting you back inside without drilling or damaging your hardware whenever possible.",
    features: [
      "24/7 Emergency Response",
      "Bedroom / Bathroom Lockouts",
      "Garage Door Keypad Reset",
      "Safe Opening",
    ],
  },
]

const comparisonData = [
  { scenario: "Lost Keys / New Home", rekey: "Best Option", replace: "Unnecessary unless locks are old" },
  { scenario: "Damaged / Rusty Locks", rekey: "Not Recommended", replace: "Best Option" },
  { scenario: "Want Different Style/Color", rekey: "Impossible", replace: "Best Option" },
  { scenario: "Want One Key for All Locks", rekey: "Best Option", replace: "Only if brands don't match" },
]

const faqs = [
  {
    question: "How much does it cost to rekey a house?",
    answer: "The cost to rekey a house depends on the number of locks, but it's typically much more affordable than replacing all the hardware. Call us for a free quote based on your specific needs.",
  },
  {
    question: "Can you rekey my locks so one key opens everything?",
    answer: "Yes! We can rekey all your locks to work with a single master key, eliminating the need to carry multiple keys for your home.",
  },
  {
    question: "I just bought a new home. Should I change the locks?",
    answer: "We always recommend rekeying when you move into a new home. You never know how many copies of the keys are floating around from previous owners, contractors, or neighbors.",
  },
  {
    question: "Do you install smart locks like Ring or Nest?",
    answer: "Yes, we install all major smart lock brands including Ring, Nest, Schlage, Yale, August, Kwikset, and more. We can also help you choose the best option for your needs.",
  },
  {
    question: "What is lock bumping and how do I prevent it?",
    answer: "Lock bumping is a technique using a special key to quickly open standard pin tumbler locks. We can install bump-resistant or high-security locks that are immune to this technique.",
  },
  {
    question: "Can you open a locked bedroom or bathroom door?",
    answer: "Yes, interior lockouts are quick and easy for us. We can open most interior doors in minutes without any damage.",
  },
  {
    question: "Do you repair sliding glass door locks?",
    answer: "Yes, we repair and replace locks on sliding glass doors and can also install additional security measures like security bars and foot locks.",
  },
  {
    question: "How quickly can you get to my house for an emergency lockout?",
    answer: "Our typical response time is 20-30 minutes anywhere in the Phoenix Metro Area. We have technicians stationed throughout the valley for rapid response.",
  },
  {
    question: "Do you install high-security deadbolts?",
    answer: "Yes, we install high-security deadbolts from brands like Medeco, Mul-T-Lock, and Abloy that offer superior protection against picking, bumping, and drilling.",
  },
  {
    question: "Are your residential locksmiths background checked?",
    answer: "Yes, all of our technicians undergo thorough background checks and are licensed, bonded, and insured for your peace of mind.",
  },
]

// Service Schema
const serviceSchema = {
  '@context': 'https://schema.org',
  '@type': 'Service',
  name: 'Residential Locksmith Service',
  serviceType: 'Residential Locksmith',
  provider: {
    '@type': 'LocalBusiness',
    name: 'Alcatraz Lock & Key',
    telephone: '+1-602-677-5045',
  },
  areaServed: {
    '@type': 'City',
    name: 'Phoenix',
  },
  description: 'Professional residential locksmith services including lock rekeying, smart lock installation, house lockouts, deadbolt installation, and door lock repair.',
}

// FAQ Schema
const faqSchema = {
  '@context': 'https://schema.org',
  '@type': 'FAQPage',
  mainEntity: faqs.map(faq => ({
    '@type': 'Question',
    name: faq.question,
    acceptedAnswer: {
      '@type': 'Answer',
      text: faq.answer,
    },
  })),
}

// Breadcrumb Schema
const breadcrumbSchema = {
  '@context': 'https://schema.org',
  '@type': 'BreadcrumbList',
  itemListElement: [
    { '@type': 'ListItem', position: 1, name: 'Home', item: 'https://alcatrazlock.com' },
    { '@type': 'ListItem', position: 2, name: 'Residential Locksmith', item: 'https://alcatrazlock.com/residential' },
  ],
}

export default function ResidentialPage() {
  return (
    <>
      <Script id="residential-service-schema" type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(serviceSchema) }} />
      <Script id="residential-faq-schema" type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }} />
      <Script id="residential-breadcrumb-schema" type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />
    <div className="bg-zinc-950">
      {/* Hero Section */}
      <section className="py-16 md:py-24 bg-zinc-900">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center gap-2 text-amber-500 text-sm font-medium mb-4">
            <Home className="w-4 h-4" />
            Residential Services
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Home Security Experts
          </h1>
          <p className="text-xl text-zinc-400 max-w-3xl">
            Protecting your family and property with professional residential locksmith services.
          </p>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-12">
              {/* Intro */}
              <div className="prose prose-invert max-w-none">
                <h2 className="text-2xl font-bold text-white mb-4">Your Home&apos;s First Line of Defense</h2>
                <p className="text-zinc-400">
                  Your home is your sanctuary, and keeping it secure is our top priority. At Alcatraz Locksmith, we provide comprehensive residential locksmith services designed to give you peace of mind. Whether you&apos;ve just moved into a new home and need to rekey your locks, or you&apos;re looking to upgrade to the latest smart home security technology, our certified technicians are here to help.
                </p>
                <p className="text-zinc-400">
                  We understand that residential security isn&apos;t one-size-fits-all. That&apos;s why we offer personalized security assessments to identify vulnerabilities in your home&apos;s defenses. From reinforcing door jambs to installing high-security deadbolts that resist picking and drilling, we ensure your home is protected against modern threats.
                </p>
                <p className="text-zinc-400">
                  Locked out? Don&apos;t panic. Our 24/7 emergency mobile service means we&apos;re always just a phone call away. We treat every home we visit with the utmost respect, ensuring clean, professional, and damage-free service every time. We also offer <Link href="/automotive" className="text-amber-500 hover:underline">automotive locksmith</Link> services for car lockouts and key replacement, as well as <Link href="/safe-services" className="text-amber-500 hover:underline">safe services</Link> for home safes. Trust the local experts who have been securing <Link href="/service-areas" className="text-amber-500 hover:underline">Phoenix metro area</Link> homes for over a decade.
                </p>
              </div>

              {/* Services */}
              <div>
                <h2 className="text-2xl font-bold text-white mb-6">Residential Security Solutions</h2>
                <div className="space-y-8">
                  {services.map((service, index) => (
                    <div key={index} className="bg-zinc-900 border border-zinc-800 rounded-xl p-6">
                      <h3 className="text-xl font-semibold text-white mb-3">{service.title}</h3>
                      <p className="text-zinc-400 mb-4">{service.description}</p>
                      <div className="grid grid-cols-2 gap-2">
                        {service.features.map((feature, i) => (
                          <div key={i} className="flex items-center gap-2 text-sm text-zinc-300">
                            <CheckCircle className="w-4 h-4 text-amber-500 flex-shrink-0" />
                            {feature}
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Comparison Table */}
              <div>
                <h2 className="text-2xl font-bold text-white mb-6">Rekey vs. Replace: What Do You Need?</h2>
                <div className="bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-zinc-800">
                        <th className="text-left text-zinc-400 font-medium p-4">Scenario</th>
                        <th className="text-left text-amber-500 font-medium p-4">Rekeying (Cheaper)</th>
                        <th className="text-left text-zinc-400 font-medium p-4">Replacement (Upgrade)</th>
                      </tr>
                    </thead>
                    <tbody>
                      {comparisonData.map((row, index) => (
                        <tr key={index} className="border-b border-zinc-800 last:border-0">
                          <td className="text-zinc-300 p-4">{row.scenario}</td>
                          <td className="text-white p-4">{row.rekey}</td>
                          <td className="text-zinc-500 p-4">{row.replace}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* FAQ */}
              <div>
                <h2 className="text-2xl font-bold text-white mb-6">Residential Locksmith FAQ</h2>
                <Accordion type="single" collapsible className="space-y-2">
                  {faqs.map((faq, index) => (
                    <AccordionItem
                      key={index}
                      value={`item-${index}`}
                      className="bg-zinc-900 border border-zinc-800 rounded-lg px-4"
                    >
                      <AccordionTrigger className="text-white hover:text-amber-500 text-left">
                        {faq.question}
                      </AccordionTrigger>
                      <AccordionContent className="text-zinc-400">
                        {faq.answer}
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </div>
            </div>

            {/* Sidebar */}
            <div className="lg:col-span-1">
              <div className="sticky top-24">
                <QuoteSidebar />
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
    </>
  )
}

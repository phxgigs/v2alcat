import { Metadata } from "next"
import Link from "next/link"
import { MapPin, Clock, Truck, Key, CheckCircle, ChevronRight, Car, Home, Building2, Lock } from "lucide-react"
import { QuoteSidebar } from "@/components/quote-sidebar"
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"

export const metadata: Metadata = {
  title: "Locksmith Service Areas Phoenix | Mobile Locksmith Near Me",
  description: "Mobile locksmith service covering Phoenix, Scottsdale, Tempe, Glendale, Peoria, Paradise Valley, and surrounding areas. Fast 20-minute response time.",
}

const serviceAreas = [
  {
    city: "Phoenix",
    slug: "phoenix",
    description: "As the capital of Arizona, Phoenix is a bustling metropolis where security is paramount. From the historic districts to the modern downtown high-rises, we provide comprehensive security solutions tailored to the unique needs of Phoenix residents and businesses. We cover the entire Valley of the Sun with rapid response times.",
  },
  {
    city: "Scottsdale",
    slug: "scottsdale",
    description: "Known for its luxury homes, high-end shopping, and vibrant nightlife, Scottsdale requires top-tier security services. We specialize in high-security residential installations and commercial access control systems that meet the aesthetic and safety standards of Scottsdale's premier properties.",
  },
  {
    city: "Tempe",
    slug: "tempe",
    description: "Home to Arizona State University and a thriving business district, Tempe is a dynamic city with diverse security needs. We provide student housing lock services, commercial security for tech companies, and automotive locksmith services for the busy Mill Avenue area.",
  },
  {
    city: "Glendale",
    slug: "glendale",
    description: "From the sports entertainment district to historic downtown, Glendale is a major hub in the West Valley. We offer specialized commercial services for entertainment venues and reliable residential security for Glendale's growing neighborhoods.",
  },
  {
    city: "Peoria",
    slug: "peoria",
    description: "Peoria's rapid growth and mix of urban and outdoor lifestyles create unique security challenges. We offer robust residential lock solutions for new developments and specialized automotive services for outdoor enthusiasts visiting Lake Pleasant.",
  },
  {
    city: "Paradise Valley",
    slug: "paradise-valley",
    description: "As Arizona's wealthiest municipality, Paradise Valley demands the highest level of discretion and security. We specialize in luxury home security, high-end safe installation, and advanced access control systems for estates and resorts.",
  },
  {
    city: "Sun City",
    slug: "sun-city",
    description: "Serving the nation's premier active adult community, we understand the specific needs of Sun City residents. We offer senior-friendly lock solutions, medical alert system integration, and golf cart key services.",
  },
  {
    city: "Anthem",
    slug: "anthem",
    description: "Located in the northern foothills, Anthem is a master-planned community that values safety and family. We provide comprehensive residential security audits and community-focused locksmith services to keep Anthem secure.",
  },
]

const responseTimes = [
  { area: "Phoenix (Central)", time: "15 - 20 Minutes", availability: "24/7 Emergency" },
  { area: "Scottsdale", time: "20 - 30 Minutes", availability: "24/7 Emergency" },
  { area: "Tempe / Mesa", time: "20 - 30 Minutes", availability: "24/7 Emergency" },
  { area: "Glendale / Peoria", time: "20 - 30 Minutes", availability: "24/7 Emergency" },
  { area: "Paradise Valley", time: "20 - 30 Minutes", availability: "24/7 Emergency" },
  { area: "Anthem / North Valley", time: "30 - 45 Minutes", availability: "Same Day Service" },
]

const benefits = [
  {
    icon: Truck,
    title: "Convenience",
    description: "We come to you. No need to tow your car or remove your home locks and bring them to a shop. We handle everything on-site.",
  },
  {
    icon: Clock,
    title: "Speed",
    description: "When you're locked out, every minute counts. Our dispatched mobile units are already on the road, ready to divert to your location immediately.",
  },
  {
    icon: MapPin,
    title: "Security",
    description: "We can assess your security needs in person. Seeing the door, frame, and environment allows us to recommend the best hardware for your specific situation.",
  },
  {
    icon: Key,
    title: "On-Site Key Testing",
    description: "We cut and test keys right there. You don't have to worry about driving home only to find out your new key doesn't work.",
  },
]

const faqs = [
  {
    question: "How far do you travel for locksmith services?",
    answer: "We cover the entire Phoenix Metropolitan area, including cities up to 45 minutes from central Phoenix. This includes Anthem, Queen Creek, and surrounding communities.",
  },
  {
    question: "Is there an extra charge for mileage?",
    answer: "No, our service call fee is the same throughout our primary service area. There may be a small additional fee for locations outside our standard coverage zone.",
  },
  {
    question: "Do you have technicians in my city right now?",
    answer: "We have technicians stationed throughout the valley. When you call, we dispatch the closest available technician to minimize your wait time.",
  },
  {
    question: "Can you come to my location for a car key replacement?",
    answer: "Yes! Our mobile units are fully equipped to cut and program car keys at any location - your home, office, or wherever your vehicle is located.",
  },
  {
    question: "Do you offer service on weekends and holidays?",
    answer: "Yes, we operate 24/7/365. Emergencies don't wait for business hours, and neither do we.",
  },
  {
    question: "What is your average response time?",
    answer: "Our average response time is 20-30 minutes throughout the Phoenix Metro Area. Response times may be slightly longer during peak hours or for remote locations.",
  },
  {
    question: "Do I need to tow my car to your shop?",
    answer: "No! We are a fully mobile locksmith service. We come to wherever your vehicle is located with all the equipment needed to service it on-site.",
  },
  {
    question: "Are you a local company or a national call center?",
    answer: "We are a local Phoenix-based company, not a national call center. When you call us, you're talking to people who know the valley and can dispatch local technicians.",
  },
  {
    question: "Do you service gated communities?",
    answer: "Yes, we service all gated communities. Please let us know the community name when you call so we can coordinate entry with security if needed.",
  },
  {
    question: "Can I schedule an appointment for a specific time?",
    answer: "Yes, we offer scheduled appointments for non-emergency services. We'll give you a 2-hour window and call when the technician is on the way.",
  },
]

export default function ServiceAreasPage() {
  return (
    <div className="bg-zinc-950">
      {/* Hero Section */}
      <section className="py-16 md:py-24 bg-zinc-900">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center gap-2 text-amber-500 text-sm font-medium mb-4">
            <MapPin className="w-4 h-4" />
            Serving The Entire Valley
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Phoenix Metro Service Areas
          </h1>
          <p className="text-xl text-zinc-400 max-w-3xl">
            Fast, mobile locksmith service to Phoenix, Scottsdale, Tempe, Glendale, and surrounding cities.
          </p>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-12">
              {/* Intro */}
              <div className="prose prose-invert max-w-none">
                <h2 className="text-2xl font-bold text-white mb-4">We Come To You - Anywhere in the Valley</h2>
                <p className="text-zinc-400">
                  Alcatraz Locksmith is a fully mobile locksmith service. We don&apos;t just have a shop you have to drive to; we bring the shop to you. Our fleet of service vehicles is equipped with the latest key cutting machines, programming tools, and a wide inventory of locks and hardware. This allows us to solve 99% of lock and key problems on-site in a single visit.
                </p>
                <p className="text-zinc-400">
                  We understand that when you need a locksmith, you often need one now. That&apos;s why we have technicians strategically stationed throughout the Phoenix Metropolitan area. Whether you&apos;re in the heart of downtown Phoenix, the suburbs of Peoria, or the luxury estates of Paradise Valley, we have a technician nearby ready to respond.
                </p>
                <p className="text-zinc-400">
                  Our standard response time for emergency calls is 20-30 minutes. We cover a wide radius, ensuring that no matter where you are in the Valley of the Sun, professional security help is just a phone call away.
                </p>
              </div>

              {/* Service Area Cards */}
              <div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {serviceAreas.map((area) => (
                    <Link 
                      key={area.city} 
                      href={`/locations/${area.slug}`}
                      className="bg-zinc-900 border border-zinc-800 hover:border-amber-500 rounded-xl p-6 transition-colors"
                    >
                      <h3 className="text-xl font-semibold text-white mb-2">{area.city} Locksmith</h3>
                      <p className="text-zinc-400 text-sm mb-4">{area.description}</p>
                      <span className="text-amber-500 text-sm font-medium flex items-center gap-1 group-hover:gap-2 transition-all">
                        View Service Area <ChevronRight className="w-4 h-4" />
                      </span>
                    </Link>
                  ))}
                </div>
              </div>

              {/* Response Times Table */}
              <div>
                <h2 className="text-2xl font-bold text-white mb-6">Service Radius & Response Times</h2>
                <div className="bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-zinc-800">
                        <th className="text-left text-zinc-400 font-medium p-4">City / Area</th>
                        <th className="text-left text-amber-500 font-medium p-4">Est. Arrival Time</th>
                        <th className="text-left text-zinc-400 font-medium p-4">Service Availability</th>
                      </tr>
                    </thead>
                    <tbody>
                      {responseTimes.map((row, index) => (
                        <tr key={index} className="border-b border-zinc-800 last:border-0">
                          <td className="text-white p-4">{row.area}</td>
                          <td className="text-zinc-300 p-4">{row.time}</td>
                          <td className="text-zinc-400 p-4">{row.availability}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Benefits */}
              <div>
                <h2 className="text-2xl font-bold text-white mb-6">Why Choose a Mobile Locksmith?</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {benefits.map((benefit, index) => (
                    <div key={index} className="bg-zinc-900 border border-zinc-800 rounded-xl p-6">
                      <div className="w-10 h-10 bg-amber-500/10 rounded-lg flex items-center justify-center mb-4">
                        <benefit.icon className="w-5 h-5 text-amber-500" />
                      </div>
                      <h3 className="text-lg font-semibold text-white mb-2">{benefit.title}</h3>
                      <p className="text-zinc-400 text-sm">{benefit.description}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* FAQ */}
              <div>
                <h2 className="text-2xl font-bold text-white mb-6">Service Area FAQ</h2>
                <Accordion type="single" collapsible className="space-y-2">
                  {faqs.map((faq, index) => (
                    <AccordionItem
                      key={index}
                      value={`item-${index}`}
                      className="bg-zinc-900 border border-zinc-800 rounded-lg px-4"
                    >
                      <AccordionTrigger className="text-white hover:text-amber-500 text-left">
                        {faq.question}
                      </AccordionTrigger>
                      <AccordionContent className="text-zinc-400">
                        {faq.answer}
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </div>
            </div>

            {/* Sidebar */}
            <div className="lg:col-span-1">
              <div className="sticky top-24">
                {/* Quote Sidebar */}
                <div className="space-y-6">
                  <QuoteSidebar />

                  {/* Services Box */}
                  <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6">
                    <h3 className="text-lg font-semibold text-white mb-4">Our Services</h3>
                    <ul className="space-y-2">
                      <li>
                        <Link href="/automotive" className="flex items-center gap-2 text-zinc-400 hover:text-amber-500 transition-colors">
                          <Car className="w-4 h-4" />
                          Automotive Locksmith
                        </Link>
                      </li>
                      <li>
                        <Link href="/residential" className="flex items-center gap-2 text-zinc-400 hover:text-amber-500 transition-colors">
                          <Home className="w-4 h-4" />
                          Residential Locksmith
                        </Link>
                      </li>
                      <li>
                        <Link href="/commercial" className="flex items-center gap-2 text-zinc-400 hover:text-amber-500 transition-colors">
                          <Building2 className="w-4 h-4" />
                          Commercial Locksmith
                        </Link>
                      </li>
                      <li>
                        <Link href="/safe-services" className="flex items-center gap-2 text-zinc-400 hover:text-amber-500 transition-colors">
                          <Lock className="w-4 h-4" />
                          Safe Services
                        </Link>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

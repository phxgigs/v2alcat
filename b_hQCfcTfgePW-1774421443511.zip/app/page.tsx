import Link from "next/link"
import { Metadata } from "next"
import { Phone, Car, Home, Building2, Lock, MapPin, Star, Shield, Clock, Zap, ChevronRight } from "lucide-react"

export const metadata: Metadata = {
  title: "Phoenix Locksmith | 24/7 Emergency Mobile Lock & Key Service | Alcatraz Lock",
  description: "24/7 Emergency locksmith in Phoenix. Car lockouts, key replacement, transponder programming, motorcycle keys, RV locksmith, residential & commercial locks. Best locksmith near me. Licensed & insured. Call (602) 677-5045",
  keywords: ["locksmith", "locksmith phoenix", "phoenix locksmith", "locksmith phoenix az", "locksmiths phoenix", "car locksmith phoenix", "auto locksmith phoenix", "best locksmith near me", "car key replacement near me", "locked keys in car near me", "car lockout service near me", "key fob replacement near me", "mobile car locksmith near me"],
}

const services = [
  {
    icon: Car,
    title: "Automotive Locksmith",
    description: "Car lockouts, car key replacement, key fob programming, transponder keys, motorcycle keys, RV locksmith, and ignition repair for all makes including BMW, Honda, VW.",
    href: "/automotive",
  },
  {
    icon: Home,
    title: "Residential Locksmith",
    description: "House lockouts, lock rekeying, door lock repair, deadbolt installation, smart lock setup, and duplicate keys made for your home.",
    href: "/residential",
  },
  {
    icon: Building2,
    title: "Commercial Locksmith",
    description: "Business security solutions, master key systems, commercial door locks, access control, and panic bar installation.",
    href: "/commercial",
  },
  {
    icon: Lock,
    title: "Safe Services",
    description: "Safe cracking, safe repair, safe locksmith services, combination changes, and professional safe moving services.",
    href: "/safe-services",
  },
]

const serviceAreas = [
  { name: "Phoenix", href: "/locations/phoenix" },
  { name: "Scottsdale", href: "/locations/scottsdale" },
  { name: "Tempe", href: "/locations/tempe" },
  { name: "Mesa", href: "/service-areas" },
  { name: "Glendale", href: "/locations/glendale" },
  { name: "Peoria", href: "/locations/peoria" },
  { name: "Paradise Valley", href: "/locations/paradise-valley" },
  { name: "Chandler", href: "/service-areas" },
  { name: "Gilbert", href: "/service-areas" },
  { name: "Anthem", href: "/locations/anthem" },
  { name: "Sun City", href: "/locations/sun-city" },
  { name: "Surprise", href: "/service-areas" },
]

const reviews = [
  {
    name: "Michael R.",
    location: "Phoenix, AZ",
    rating: 5,
    text: "Locked out of my car at 2 AM. They arrived in 15 minutes and had me back in my vehicle in under 5 minutes. Professional and affordable!",
  },
  {
    name: "Sarah T.",
    location: "Scottsdale, AZ",
    rating: 5,
    text: "Just moved into a new home and needed all the locks rekeyed. They did an amazing job and even gave me tips on improving my home security.",
  },
  {
    name: "David L.",
    location: "Tempe, AZ",
    rating: 5,
    text: "Lost my only car key with the transponder chip. They made a new one on the spot for half what the dealer quoted. Highly recommend!",
  },
]

export default function HomePage() {
  return (
    <div className="bg-zinc-950">
      {/* Hero Section */}
      <section className="relative py-20 md:py-32 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-zinc-900 via-zinc-950 to-zinc-900" />
        <div className="relative max-w-7xl mx-auto px-4">
          <div className="text-center max-w-4xl mx-auto">
            <div className="inline-flex items-center gap-2 bg-amber-500/10 text-amber-500 px-4 py-2 rounded-full text-sm font-medium mb-6">
              <Clock className="w-4 h-4" />
              24/7 Emergency Service Available
            </div>
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight">
              Phoenix Locksmith
              <span className="block text-amber-500">24/7 Emergency Mobile Service</span>
            </h1>
            <p className="text-xl text-zinc-400 mb-8 max-w-2xl mx-auto">
              Fast, reliable mobile locksmith services throughout the Phoenix Metro Area. 
              Car lockouts, locked keys in car, car key replacement, key fob programming, house lockouts, and more. Licensed, bonded, and insured. The best locksmith near you.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <a
                href="tel:6026775045"
                className="flex items-center gap-2 bg-amber-500 hover:bg-amber-600 text-black font-bold px-8 py-4 rounded-lg transition-colors text-lg"
              >
                <Phone className="w-5 h-5" />
                (602) 677-5045
              </a>
              <Link
                href="/contact"
                className="flex items-center gap-2 bg-zinc-800 hover:bg-zinc-700 text-white font-semibold px-8 py-4 rounded-lg transition-colors"
              >
                Get a Free Quote
                <ChevronRight className="w-5 h-5" />
              </Link>
            </div>
            <div className="flex flex-wrap items-center justify-center gap-6 mt-10 text-sm text-zinc-400">
              <div className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-amber-500" />
                <span>Licensed & Insured</span>
              </div>
              <div className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-amber-500" />
                <span>20-Minute Response</span>
              </div>
              <div className="flex items-center gap-2">
                <Star className="w-5 h-5 text-amber-500" />
                <span>5-Star Rated</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 bg-zinc-900">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Our Services</h2>
            <p className="text-zinc-400 max-w-2xl mx-auto">
              Comprehensive locksmith services for automotive, residential, and commercial needs.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {services.map((service) => (
              <Link
                key={service.title}
                href={service.href}
                className="group bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 rounded-xl p-6 transition-all hover:border-amber-500"
              >
                <div className="w-12 h-12 bg-amber-500/10 rounded-lg flex items-center justify-center mb-4 group-hover:bg-amber-500/20 transition-colors">
                  <service.icon className="w-6 h-6 text-amber-500" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">{service.title}</h3>
                <p className="text-zinc-400 text-sm mb-4">{service.description}</p>
                <span className="text-amber-500 text-sm font-medium flex items-center gap-1 group-hover:gap-2 transition-all">
                  Learn More <ChevronRight className="w-4 h-4" />
                </span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Service Areas Section */}
      <section className="py-20 bg-zinc-950">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Service Areas</h2>
            <p className="text-zinc-400 max-w-2xl mx-auto">
              We proudly serve the entire Phoenix Metropolitan Area with fast mobile service.
            </p>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {serviceAreas.map((area) => (
              <Link
                key={area.name}
                href={area.href}
                className="flex items-center gap-2 bg-zinc-900 border border-zinc-800 hover:border-amber-500 rounded-lg px-4 py-3 transition-colors"
              >
                <MapPin className="w-4 h-4 text-amber-500 flex-shrink-0" />
                <span className="text-zinc-300 text-sm">{area.name}</span>
              </Link>
            ))}
          </div>
          <div className="text-center mt-8">
            <Link
              href="/service-areas"
              className="inline-flex items-center gap-2 text-amber-500 hover:text-amber-400 font-medium transition-colors"
            >
              View All Service Areas <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* Reviews Section */}
      <section className="py-20 bg-zinc-900">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Customer Reviews</h2>
            <p className="text-zinc-400 max-w-2xl mx-auto">
              See what our satisfied customers have to say about our service.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {reviews.map((review, index) => (
              <div
                key={index}
                className="bg-zinc-800 border border-zinc-700 rounded-xl p-6"
              >
                <div className="flex items-center gap-1 mb-4">
                  {[...Array(review.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-amber-500 fill-amber-500" />
                  ))}
                </div>
                <p className="text-zinc-300 mb-4">{`"${review.text}"`}</p>
                <div>
                  <p className="text-white font-semibold">{review.name}</p>
                  <p className="text-zinc-500 text-sm">{review.location}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Detailed Services Section */}
      <section className="py-20 bg-zinc-950">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Automotive Column */}
            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-white">Automotive Locksmith Services</h3>
              <p className="text-zinc-400">
                Locked your keys in your car? Lost your only car key? Our <Link href="/automotive" className="text-amber-500 hover:underline">automotive locksmith</Link> team handles all car key and lock emergencies 24/7.
              </p>
              <ul className="space-y-2 text-zinc-300">
                <li className="flex items-center gap-2"><ChevronRight className="w-4 h-4 text-amber-500" /> Car lockout service - we unlock any vehicle</li>
                <li className="flex items-center gap-2"><ChevronRight className="w-4 h-4 text-amber-500" /> Car key replacement for all makes and models</li>
                <li className="flex items-center gap-2"><ChevronRight className="w-4 h-4 text-amber-500" /> Key fob programming and replacement</li>
                <li className="flex items-center gap-2"><ChevronRight className="w-4 h-4 text-amber-500" /> Transponder key programming</li>
                <li className="flex items-center gap-2"><ChevronRight className="w-4 h-4 text-amber-500" /> <Link href="/automotive" className="text-amber-500 hover:underline">Ignition repair</Link> and ignition replacement</li>
                <li className="flex items-center gap-2"><ChevronRight className="w-4 h-4 text-amber-500" /> Motorcycle key replacement</li>
                <li className="flex items-center gap-2"><ChevronRight className="w-4 h-4 text-amber-500" /> RV locksmith services</li>
              </ul>
              <p className="text-zinc-500 text-sm">
                We service all car brands: BMW, Honda, Toyota, Ford, Chevy, Mercedes, Audi, VW, Nissan, Hyundai, Kia, Lexus, and more.
              </p>
            </div>

            {/* Safe Services Column */}
            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-white">Safe Locksmith Services</h3>
              <p className="text-zinc-400">
                Locked out of your safe? Our certified <Link href="/safe-services" className="text-amber-500 hover:underline">safe locksmith</Link> technicians can open, repair, and service all types of safes.
              </p>
              <ul className="space-y-2 text-zinc-300">
                <li className="flex items-center gap-2"><ChevronRight className="w-4 h-4 text-amber-500" /> Safe cracking and safe opening service</li>
                <li className="flex items-center gap-2"><ChevronRight className="w-4 h-4 text-amber-500" /> Gun safe lockout and gun safe opening</li>
                <li className="flex items-center gap-2"><ChevronRight className="w-4 h-4 text-amber-500" /> Safe combination change and reset</li>
                <li className="flex items-center gap-2"><ChevronRight className="w-4 h-4 text-amber-500" /> Safe repair and safe lock repair</li>
                <li className="flex items-center gap-2"><ChevronRight className="w-4 h-4 text-amber-500" /> Safe installation and safe moving</li>
                <li className="flex items-center gap-2"><ChevronRight className="w-4 h-4 text-amber-500" /> Emergency safe unlock - 24/7 service</li>
                <li className="flex items-center gap-2"><ChevronRight className="w-4 h-4 text-amber-500" /> Sentry safe key replacement</li>
              </ul>
              <p className="text-zinc-500 text-sm">
                We handle residential safes, commercial safes, gun safes, vault doors, and deposit boxes.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-zinc-900">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Need a Locksmith Now?
          </h2>
          <p className="text-zinc-400 mb-8 text-lg">
            We are available 24/7 for all your lock and key emergencies. Call us now for fast, professional service.
          </p>
          <a
            href="tel:6026775045"
            className="inline-flex items-center gap-2 bg-amber-500 hover:bg-amber-600 text-black font-bold px-10 py-5 rounded-lg transition-colors text-xl"
          >
            <Phone className="w-6 h-6" />
            (602) 677-5045
          </a>
        </div>
      </section>
    </div>
  )
}

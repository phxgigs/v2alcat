import { Metadata } from "next"
import Link from "next/link"
import Script from "next/script"
import { Lock, Key, Wrench, Truck, CheckCircle } from "lucide-react"
import { QuoteSidebar } from "@/components/quote-sidebar"
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"

export const metadata: Metadata = {
  title: "Safe Locksmith Phoenix | Safe Cracking, Repair & Moving Services",
  description: "Professional safe locksmith services in Phoenix. Safe opening, safe cracking, safe repair, gun safe lockout, safe combination change, safe installation. Certified safe technicians. 24/7 emergency safe unlock service.",
  keywords: [
    "safe locksmith near me", "safe lockout", "safe locksmith", "safe cracking service", "gun safe lockout",
    "safe combination change", "safe repair near me", "safe installation", "safe opening near me",
    "safe unlocking service near me", "safe repair", "safe lock repair", "safe key replacement",
    "sentry safe key replacement", "safe cracking", "safe unlock near me", "safe locksmith phoenix",
    "locksmith to open safe near me", "safe openers near me", "emergency safe unlock",
    "safe lock repair near me", "safe unlocking near me", "safe cracking near me",
    "gun safe locksmith near me", "safe combination reset near me", "safe repair service near me",
    "safe installation near me", "safe locksmith service", "locked safe near me",
    "how to open a safe without combination", "safe locksmiths near me", "safe vault opening service",
    "residential safe opening", "commercial safe unlock", "gun safe opening near me"
  ],
}

const services = [
  {
    title: "Safe Opening & Cracking Service",
    description: "Lost combination? Malfunctioning lock? Inherited a locked safe? Our safe cracking service can open it. We prioritize non-destructive entry methods like manipulation (listening to the lock) to preserve the integrity of your safe whenever possible. Emergency safe unlock available 24/7.",
    features: [
      "Lost Combination Retrieval",
      "Mechanical Dial Manipulation",
      "Electronic Lock Bypass",
      "Precision Drilling (if needed)",
      "Jammed Bolt Repair",
      "Burglary Repair",
    ],
  },
  {
    title: "Gun Safe Locksmith Services",
    description: "Gun safe lockout? We specialize in gun safe opening, gun safe lockout service, and gun safe repairs. Whether you have a Liberty, Fort Knox, Browning, or any other brand, we can get your gun safe open without damage and reset your combination.",
    features: [
      "Gun Safe Lockout Service",
      "Gun Safe Opening",
      "Gun Safe Combination Reset",
      "Gun Safe Lock Repair",
      "Gun Safe Installation",
      "Electronic Lock Upgrades",
    ],
  },
  {
    title: "Safe Repair & Combination Change",
    description: "Just like a car, a safe's locking mechanism needs regular maintenance. We offer safe repair service, safe lock repair, and safe combination change. We can also modernize your safe with a new electronic keypad for faster access.",
    features: [
      "Safe Combination Change",
      "Safe Combination Reset",
      "Dial to Keypad Conversion",
      "Safe Lock Repair",
      "Safe Key Replacement",
      "Sentry Safe Key Replacement",
    ],
  },
  {
    title: "Safe Installation & Moving",
    description: "Moving a 1,000-pound gun safe requires specialized equipment and expertise to avoid injury or property damage. We offer professional safe installation, safe moving, and bolting services to secure your safe to the foundation.",
    features: [
      "Safe Installation",
      "Heavy Safe Moving",
      "Bolt-Down Service",
      "Floor Safe Installation",
      "Wall Safe Installation",
      "Safe Removal & Disposal",
    ],
  },
]

const lockComparison = [
  { feature: "Reliability", mechanical: "Extremely High (Decades)", electronic: "High (Requires Batteries)" },
  { feature: "Speed of Access", mechanical: "Slow (Spinning Dial)", electronic: "Fast (Punch Code)" },
  { feature: "User Friendly", mechanical: "Requires Precision", electronic: "Very Easy / Lighted" },
  { feature: "Maintenance", mechanical: "Periodic Cleaning", electronic: "Battery Changes" },
]

const faqs = [
  {
    question: "I lost the combination to my safe. Can you open it?",
    answer: "Yes! We specialize in opening safes when the combination has been lost or forgotten. We use non-destructive methods whenever possible to preserve your safe's integrity.",
  },
  {
    question: "Can you change the combination on my safe?",
    answer: "Yes, we can change combinations on both mechanical dial locks and electronic keypad locks. We recommend changing combinations periodically for security.",
  },
  {
    question: "Do you move heavy safes?",
    answer: "Yes, we have specialized equipment for moving heavy safes, including gun safes that can weigh over 1,000 pounds. We ensure safe delivery without damage to your property.",
  },
  {
    question: "My electronic safe keypad is beeping but won't open. What's wrong?",
    answer: "This usually indicates low batteries. Try replacing the batteries first. If that doesn't work, call us - the lock may need reprogramming or the keypad may need replacement.",
  },
  {
    question: "Do you sell new safes?",
    answer: "We primarily focus on safe service, but we can recommend trusted safe dealers and help with delivery and installation of your new safe.",
  },
  {
    question: "Can you upgrade my dial lock to a digital keypad?",
    answer: "Yes, in most cases we can convert a mechanical dial lock to an electronic keypad, giving you faster and easier access while maintaining security.",
  },
  {
    question: "What is the difference between a fire safe and a burglary safe?",
    answer: "Fire safes are designed to protect contents from heat damage during a fire. Burglary safes are built with thick steel walls to resist break-in attempts. Some safes offer both ratings.",
  },
  {
    question: "Can you open a safe deposit box if I lost the key?",
    answer: "Safe deposit boxes at banks are typically handled by the bank's procedures. However, we can open personal safe deposit boxes and lock boxes that you own.",
  },
  {
    question: "How often should I service my safe?",
    answer: "We recommend having your safe serviced every 3-5 years, or immediately if you notice any issues with the lock mechanism operating smoothly.",
  },
  {
    question: "Is it possible to bolt down my safe?",
    answer: "Yes, bolting your safe to the floor is highly recommended. It prevents thieves from simply carrying the safe away and provides stability.",
  },
]

// Service Schema
const serviceSchema = {
  '@context': 'https://schema.org',
  '@type': 'Service',
  name: 'Safe Locksmith Service',
  serviceType: 'Safe Locksmith',
  provider: { '@type': 'LocalBusiness', name: 'Alcatraz Lock & Key', telephone: '+1-602-677-5045' },
  areaServed: { '@type': 'City', name: 'Phoenix' },
  description: 'Professional safe locksmith services including safe opening, safe cracking, gun safe lockout, safe combination change, safe repair, safe installation.',
}

// FAQ Schema
const faqSchema = {
  '@context': 'https://schema.org',
  '@type': 'FAQPage',
  mainEntity: faqs.map(faq => ({ '@type': 'Question', name: faq.question, acceptedAnswer: { '@type': 'Answer', text: faq.answer } })),
}

// Breadcrumb Schema
const breadcrumbSchema = {
  '@context': 'https://schema.org',
  '@type': 'BreadcrumbList',
  itemListElement: [
    { '@type': 'ListItem', position: 1, name: 'Home', item: 'https://alcatrazlock.com' },
    { '@type': 'ListItem', position: 2, name: 'Safe Services', item: 'https://alcatrazlock.com/safe-services' },
  ],
}

export default function SafeServicesPage() {
  return (
    <>
      <Script id="safe-service-schema" type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(serviceSchema) }} />
      <Script id="safe-faq-schema" type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }} />
      <Script id="safe-breadcrumb-schema" type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />
    <div className="bg-zinc-950">
      {/* Hero Section */}
      <section className="py-16 md:py-24 bg-zinc-900">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center gap-2 text-amber-500 text-sm font-medium mb-4">
            <Lock className="w-4 h-4" />
            Safe & Vault Services
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Safe Cracking & Repair
          </h1>
          <p className="text-xl text-zinc-400 max-w-3xl">
            Professional safe opening, installation, and maintenance by certified experts.
          </p>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-12">
              {/* Intro */}
              <div className="prose prose-invert max-w-none">
                <h2 className="text-2xl font-bold text-white mb-4">The Valley&apos;s Premier Safe Specialists</h2>
                <p className="text-zinc-400">
                  A safe is the last line of defense for your most valuable possessions. But when a safe malfunctions or you lose the combination, it can turn from a security asset into a major headache. Alcatraz Locksmith is one of the few companies in Arizona with certified safe technicians who specialize in the complex art of safe manipulation and repair.
                </p>
                <p className="text-zinc-400">
                  Unlike general locksmiths who may resort to destroying your safe to open it, we use advanced diagnostic tools and precision techniques to open locked safes with minimal to no damage. We work on all types of containers, from small residential fire boxes and gun safes to massive commercial bank vaults and jewelry store safes.
                </p>
                <p className="text-zinc-400">
                  Beyond opening safes, we offer comprehensive maintenance services to keep your locking mechanism operating smoothly. We can also upgrade your old mechanical dial to a modern, user-friendly electronic keypad, giving you faster access without compromising security. We also offer <Link href="/residential" className="text-amber-500 hover:underline">residential locksmith</Link> and <Link href="/commercial" className="text-amber-500 hover:underline">commercial locksmith</Link> services throughout the <Link href="/service-areas" className="text-amber-500 hover:underline">Phoenix metro area</Link>.
                </p>
              </div>

              {/* Services */}
              <div>
                <h2 className="text-2xl font-bold text-white mb-6">Safe & Vault Services</h2>
                <div className="space-y-8">
                  {services.map((service, index) => (
                    <div key={index} className="bg-zinc-900 border border-zinc-800 rounded-xl p-6">
                      <h3 className="text-xl font-semibold text-white mb-3">{service.title}</h3>
                      <p className="text-zinc-400 mb-4">{service.description}</p>
                      <div className="grid grid-cols-2 gap-2">
                        {service.features.map((feature, i) => (
                          <div key={i} className="flex items-center gap-2 text-sm text-zinc-300">
                            <CheckCircle className="w-4 h-4 text-amber-500 flex-shrink-0" />
                            {feature}
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Lock Comparison */}
              <div>
                <h2 className="text-2xl font-bold text-white mb-6">Mechanical vs. Electronic Safe Locks</h2>
                <div className="bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-zinc-800">
                        <th className="text-left text-zinc-400 font-medium p-4">Feature</th>
                        <th className="text-left text-amber-500 font-medium p-4">Mechanical Dial</th>
                        <th className="text-left text-zinc-400 font-medium p-4">Electronic Keypad</th>
                      </tr>
                    </thead>
                    <tbody>
                      {lockComparison.map((row, index) => (
                        <tr key={index} className="border-b border-zinc-800 last:border-0">
                          <td className="text-zinc-300 p-4">{row.feature}</td>
                          <td className="text-white p-4">{row.mechanical}</td>
                          <td className="text-zinc-400 p-4">{row.electronic}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* FAQ */}
              <div>
                <h2 className="text-2xl font-bold text-white mb-6">Safe Services FAQ</h2>
                <Accordion type="single" collapsible className="space-y-2">
                  {faqs.map((faq, index) => (
                    <AccordionItem
                      key={index}
                      value={`item-${index}`}
                      className="bg-zinc-900 border border-zinc-800 rounded-lg px-4"
                    >
                      <AccordionTrigger className="text-white hover:text-amber-500 text-left">
                        {faq.question}
                      </AccordionTrigger>
                      <AccordionContent className="text-zinc-400">
                        {faq.answer}
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </div>
            </div>

            {/* Sidebar */}
            <div className="lg:col-span-1">
              <div className="sticky top-24">
                <QuoteSidebar />
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
    </>
  )
}

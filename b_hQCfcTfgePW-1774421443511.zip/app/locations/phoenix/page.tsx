import { Metadata } from "next"
import Link from "next/link"
import { Phone, Clock, MapPin, Shield, Star, CheckCircle2, Car, Home, Building2, Lock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

export const metadata: Metadata = {
  title: "Phoenix Locksmith | 24/7 Emergency Lock & Key Service | Alcatraz Lock",
  description: "24/7 Emergency Locksmith in Phoenix, AZ. Fast 15-20 minute response for car lockouts, car key replacement, ignition repair, house lockouts, safe locksmith. Best locksmith near me in Phoenix. Licensed & Insured. Call (602) 677-5045",
  keywords: [
    "locksmith phoenix", "locksmith phoenix az", "phoenix locksmith", "locksmiths phoenix",
    "car locksmith phoenix", "auto locksmith phoenix", "best locksmith near me phoenix",
    "car key replacement phoenix", "car lockout phoenix", "ignition repair phoenix",
    "safe locksmith phoenix", "residential locksmith phoenix", "commercial locksmith phoenix"
  ],
}

const services = [
  { icon: Car, title: "Automotive Locksmith", description: "Car lockouts, car key replacement, key fob programming, transponder keys, ignition repair, ignition replacement, motorcycle keys", href: "/automotive" },
  { icon: Home, title: "Residential Locksmith", description: "House lockouts, lock rekeying, door lock repair, smart lock installation, deadbolts, duplicate keys", href: "/residential" },
  { icon: Building2, title: "Commercial Locksmith", description: "Business lockouts, master key systems, commercial door locks, access control, panic bars", href: "/commercial" },
  { icon: Lock, title: "Safe Services", description: "Safe cracking, safe opening, gun safe lockout, safe combination change, safe repair, safe installation", href: "/safe-services" },
]

const neighborhoods = [
  "Downtown Phoenix", "Arcadia", "Biltmore", "Camelback East", "Ahwatukee",
  "Desert Ridge", "North Mountain", "South Mountain", "Maryvale", "Encanto",
  "Central City", "Laveen", "Paradise Valley Village", "Deer Valley", "Estrella"
]

const reviews = [
  { name: "Michael R.", rating: 5, text: "Got locked out of my car at 2 AM in downtown Phoenix. They arrived in 15 minutes and had me back in my car quickly. Excellent service!", date: "2 weeks ago" },
  { name: "Sarah T.", rating: 5, text: "Needed all my locks rekeyed after moving into my new Phoenix home. Professional, fast, and fairly priced. Highly recommend!", date: "1 month ago" },
  { name: "James L.", rating: 5, text: "Lost my car keys at a Phoenix Suns game. They came out and made new keys on the spot. Lifesaver!", date: "3 weeks ago" },
]

export default function PhoenixPage() {
  return (
    <main className="min-h-screen bg-zinc-950">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-b from-zinc-900 to-zinc-950 py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 bg-amber-500/10 border border-amber-500/20 rounded-full px-4 py-2 mb-6">
              <MapPin className="w-4 h-4 text-amber-500" />
              <span className="text-amber-500 text-sm font-medium">Serving Phoenix, AZ</span>
            </div>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6">
              Phoenix Locksmith
            </h1>
            <p className="text-xl text-zinc-400 mb-8 max-w-2xl mx-auto">
              24/7 Emergency locksmith services throughout Phoenix. Fast 15-20 minute response time. Licensed, bonded, and insured.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" className="bg-amber-500 hover:bg-amber-600 text-zinc-900 font-semibold text-lg px-8">
                <a href="tel:+16026775045">
                  <Phone className="w-5 h-5 mr-2" />
                  (602) 677-5045
                </a>
              </Button>
              <Button asChild size="lg" variant="outline" className="border-zinc-700 text-white hover:bg-zinc-800">
                <Link href="/contact">Get Free Quote</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Trust Badges */}
      <section className="bg-zinc-900 border-y border-zinc-800 py-8">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            <div className="flex flex-col items-center">
              <Clock className="w-8 h-8 text-amber-500 mb-2" />
              <span className="text-white font-semibold">15-20 Min Response</span>
              <span className="text-zinc-500 text-sm">In Phoenix Area</span>
            </div>
            <div className="flex flex-col items-center">
              <Shield className="w-8 h-8 text-amber-500 mb-2" />
              <span className="text-white font-semibold">Licensed & Insured</span>
              <span className="text-zinc-500 text-sm">Fully Certified</span>
            </div>
            <div className="flex flex-col items-center">
              <Star className="w-8 h-8 text-amber-500 mb-2" />
              <span className="text-white font-semibold">5-Star Rated</span>
              <span className="text-zinc-500 text-sm">500+ Reviews</span>
            </div>
            <div className="flex flex-col items-center">
              <CheckCircle2 className="w-8 h-8 text-amber-500 mb-2" />
              <span className="text-white font-semibold">Upfront Pricing</span>
              <span className="text-zinc-500 text-sm">No Hidden Fees</span>
            </div>
          </div>
        </div>
      </section>

      {/* Services */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-white text-center mb-4">
            Locksmith Services in Phoenix
          </h2>
          <p className="text-zinc-400 text-center mb-12 max-w-2xl mx-auto">
            Complete locksmith solutions for automotive, residential, and commercial needs throughout Phoenix.
          </p>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {services.map((service) => (
              <Link key={service.title} href={service.href}>
                <Card className="bg-zinc-900 border-zinc-800 hover:border-amber-500/50 transition-colors h-full">
                  <CardContent className="p-6 text-center">
                    <service.icon className="w-12 h-12 text-amber-500 mx-auto mb-4" />
                    <h3 className="text-xl font-semibold text-white mb-2">{service.title}</h3>
                    <p className="text-zinc-400">{service.description}</p>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Neighborhoods */}
      <section className="bg-zinc-900 py-16 md:py-24">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-white text-center mb-4">
            Phoenix Neighborhoods We Serve
          </h2>
          <p className="text-zinc-400 text-center mb-12 max-w-2xl mx-auto">
            Fast response times to all Phoenix neighborhoods and surrounding areas.
          </p>
          <div className="flex flex-wrap justify-center gap-3">
            {neighborhoods.map((neighborhood) => (
              <span key={neighborhood} className="bg-zinc-800 text-zinc-300 px-4 py-2 rounded-full text-sm">
                {neighborhood}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* Reviews */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-white text-center mb-4">
            What Phoenix Customers Say
          </h2>
          <p className="text-zinc-400 text-center mb-12">Real reviews from real customers</p>
          <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {reviews.map((review, index) => (
              <Card key={index} className="bg-zinc-900 border-zinc-800">
                <CardContent className="p-6">
                  <div className="flex gap-1 mb-3">
                    {[...Array(review.rating)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 fill-amber-500 text-amber-500" />
                    ))}
                  </div>
                  <p className="text-zinc-300 mb-4">{`"${review.text}"`}</p>
                  <div className="flex justify-between items-center">
                    <span className="text-white font-semibold">{review.name}</span>
                    <span className="text-zinc-500 text-sm">{review.date}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-amber-500 py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-zinc-900 mb-4">
            Locked Out in Phoenix?
          </h2>
          <p className="text-zinc-800 text-lg mb-8 max-w-2xl mx-auto">
            {`Don't wait! Our Phoenix locksmiths are available 24/7 and can be at your location in 15-20 minutes.`}
          </p>
          <Button asChild size="lg" className="bg-zinc-900 hover:bg-zinc-800 text-white font-semibold text-lg px-8">
            <a href="tel:+16026775045">
              <Phone className="w-5 h-5 mr-2" />
              Call Now: (602) 677-5045
            </a>
          </Button>
        </div>
      </section>
    </main>
  )
}
